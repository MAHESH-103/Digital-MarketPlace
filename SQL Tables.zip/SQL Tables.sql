CREATE DATABASE digital_marketplaces;

USE digital_marketplaces;

CREATE TABLE Product (
  product_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255),
  description VARCHAR(255),
  price DECIMAL(10, 2),
  quantity_available INT,
  category VARCHAR(255)
);

CREATE TABLE Seller (
  seller_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255),
  email VARCHAR(255),
  address VARCHAR(255),
  phone_number VARCHAR(20)
);

CREATE TABLE Buyer (
  buyer_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255),
  email VARCHAR(255),
  address VARCHAR(255),
  phone_number VARCHAR(20)
);

CREATE TABLE Transaction (
  transaction_id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT,
  seller_id INT,
  buyer_id INT,
  quantity INT,
  transaction_date DATE,
  status VARCHAR(255),
  FOREIGN KEY (product_id) REFERENCES Product(product_id),
  FOREIGN KEY (seller_id) REFERENCES Seller(seller_id),
  FOREIGN KEY (buyer_id) REFERENCES Buyer(buyer_id)
);

select * from product;
desc product;
desc buyer;
select * from transaction;
desc transaction;