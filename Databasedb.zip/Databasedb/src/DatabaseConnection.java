import java.sql.*;
import java.util.Scanner;

class Product {
    int product_id;
    String name;
    String description;
    double price;
    int quantity_available;
    String category;

    public Product(int product_id, String name, String description, double price, int quantity_available, String category) {
        this.product_id = product_id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.quantity_available = quantity_available;
        this.category = category;
    }
}

class Seller {
    int seller_id;
    String name;
    String email;
    String address;
    String phone_number;

    public Seller(int seller_id, String name, String email, String address, String phone_number) {
        this.seller_id = seller_id;
        this.name = name;
        this.email = email;
        this.address = address;
        this.phone_number = phone_number;
    }
}

class Buyer {
    int buyer_id;
    String name;
    String email;
    String address;
    String phone_number;

    public Buyer(int buyer_id, String name, String email, String address, String phone_number) {
        this.buyer_id = buyer_id;
        this.name = name;
        this.email = email;
        this.address = address;
        this.phone_number = phone_number;
    }
}

class Transaction {
    int transaction_id;
    int product_id;
    int seller_id;
    int buyer_id;
    int quantity;
    Date transaction_date;
    String status;

    public Transaction(int transaction_id, int product_id, int seller_id, int buyer_id, int quantity, Date transaction_date, String status) {
        this.transaction_id = transaction_id;
        this.product_id = product_id;
        this.seller_id = seller_id;
        this.buyer_id = buyer_id;
        this.quantity = quantity;
        this.transaction_date = transaction_date;
        this.status = status;
    }
}

public class DatabaseConnection {
    static Connection conn;
    static Statement stmt;
    static ResultSet rs;

    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/digital_marketplaces", "root", "Pass@123!");
            stmt = conn.createStatement();

            Scanner scanner = new Scanner(System.in);
            int choice;

            while (true) {
                System.out.println("Console Application : Digital Marketplace");
                System.out.println("1. Product Management");
                System.out.println("2. Seller Management");
                System.out.println("3. Buyer Management");
                System.out.println("4. Transaction Management");    
                System.out.println("5. Exit");
                System.out.print("Enter your choice given above: ");
                choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        productManagement(scanner);
                        break;
                    case 2:
                        sellerManagement(scanner);
                        break;
                    case 3:
                    	buyerManagement(scanner);
                    	break;
                    case 4:
                        transactionManagement(scanner);
                        break;
                    case 5:
                        System.out.println("Exiting.....");
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC driver is not found!");
        } catch (SQLException e) {
            System.out.println("Error connecting to database: " + e.getMessage());
        }
    }

    private static void productManagement(Scanner scanner) {
        int choice;

        while (true) {
            System.out.println("Product Management");
            System.out.println("1. Add new product");
            System.out.println("2. View product details");
            System.out.println("3. Update product information");
            System.out.println("4. Delete product");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addProduct(scanner);
                    break;
                case 2:
                    viewProductDetails(scanner);
                    break;
                case 3:
                    updateProductInformation(scanner);
                    break;
                case 4:
                    deleteProduct(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void sellerManagement(Scanner scanner) {
        int choice;

        while (true) {
            System.out.println("Seller Management");
            System.out.println("1. Register new seller");
            System.out.println("2. View seller details");
            System.out.println("3. Update seller information");
            System.out.println("4. Delete seller");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    registerNewSeller(scanner);
                    break;
                case 2:
                    viewSellerDetails(scanner);
                    break;
                case 3:
                    updateSellerInformation(scanner);
                    break;
                case 4:
                    deleteSeller(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
    
    private static void buyerManagement(Scanner scanner) {
        int choice;

        while (true) {
            System.out.println("Buyer Management");
            System.out.println("1. Register new buyer");
            System.out.println("2. View buyer details");
            System.out.println("3. Update buyer information");
            System.out.println("4. Delete buyer");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    registerNewBuyer(scanner);
                    break;
                case 2:
                    viewBuyerDetails(scanner);
                    break;
                case 3:
                    updateBuyerInformation(scanner);
                    break;
                case 4:
                    deleteBuyer(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void transactionManagement(Scanner scanner) {
        int choice;

        while (true) {
            System.out.println("Transaction Management");
            System.out.println("1. Process new transaction");
            System.out.println("2. View transaction details");
            System.out.println("3. Update transaction status");
            System.out.println("4. Refund transaction");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    processNewTransaction(scanner);
                    break;
                case 2:
                    viewTransactionDetails(scanner);
                    break;
                case 3:
                    updateTransactionStatus(scanner);
                    break;
                case 4:
                    refundTransaction(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addProduct(Scanner scanner) {
        System.out.print("Enter product name: ");
        String name = scanner.next();
        System.out.print("Enter product description: ");
        String description = scanner.next();
        System.out.print("Enter product price: ");
        double price = scanner.nextDouble();
        System.out.print("Enter quantity available: ");
        int quantity_available = scanner.nextInt();
        System.out.print("Enter product category: ");
        String category = scanner.next();

        try {
            stmt.executeUpdate("INSERT INTO Product (name, description, price, quantity_available, category) VALUES ('" + name + "', '" + description + "', " + price + ", " + quantity_available + ", '" + category + "')");
            System.out.println("Product added successfully!");
        } catch (SQLException e) {
            System.out.println("Error adding product: " + e.getMessage());
        }
    }

    private static void viewProductDetails(Scanner scanner) {
        System.out.print("Enter product ID: ");
        int product_id = scanner.nextInt();

        try {
            rs = stmt.executeQuery("SELECT * FROM Product WHERE product_id = " + product_id);
            if (rs.next()) {
                System.out.println("Product ID: " + rs.getInt("product_id"));
                System.out.println("Product Name: " + rs.getString("name"));
                System.out.println("Product Description: " + rs.getString("description"));
                System.out.println("Product Price: " + rs.getDouble("price"));
                System.out.println("Quantity Available: " + rs.getInt("quantity_available"));
                System.out.println("Product Category: " + rs.getString("category"));
            } else {
                System.out.println("Product not found!");
            }
        } catch (SQLException e) {
            System.out.println("Error viewing product details: " + e.getMessage());
        }
    }

    private static void updateProductInformation(Scanner scanner) {
        System.out.print("Enter product ID: ");
        int product_id = scanner.nextInt();
        System.out.print("Enter new product name: ");
        String name = scanner.next();
        System.out.print("Enter new product description: ");
        String description = scanner.next();
        System.out.print("Enter new product price: ");
        double price = scanner.nextDouble();
        System.out.print("Enter new quantity available: ");
        int quantity_available = scanner.nextInt();
        System.out.print("Enter new product category: ");
        String category = scanner.next();

        try {
            stmt.executeUpdate("UPDATE Product SET name= '" + name + "', description = '" + description + "', price = " + price + ", quantity_available = " + quantity_available + ", category = '" + category + "' WHERE product_id = " + product_id);
            System.out.println("Product information updated successfully!");
        } catch (SQLException e) {
            System.out.println("Error updating product information: " + e.getMessage());
        }
    }

    private static void deleteProduct(Scanner scanner) {
        System.out.print("Enter product ID: ");
        int product_id = scanner.nextInt();

        try {
            stmt.executeUpdate("DELETE FROM Product WHERE product_id = " + product_id);
            System.out.println("Product deleted successfully!");
        } catch (SQLException e) {
            System.out.println("Error deleting product: " + e.getMessage());
        }
    }
    
    private static void registerNewSeller(Scanner scanner) {
        System.out.print("Enter seller name: ");
        String name = scanner.next();
        System.out.print("Enter seller email: ");
        String email = scanner.next();
        System.out.print("Enter seller address: ");
        String address = scanner.next();
        System.out.print("Enter seller phone number: ");
        String phone_number = scanner.next();

        try {
            stmt.executeUpdate("INSERT INTO Seller (name, email, address, phone_number) VALUES ('" + name + "', '" + email + "', '" + address + "', '" + phone_number + "')");
            System.out.println("Seller registered successfully!");
        } catch (SQLException e) {
            System.out.println("Error registering seller: " + e.getMessage());
        }
    }

    private static void viewSellerDetails(Scanner scanner) {
        System.out.print("Enter seller ID: ");
        int seller_id = scanner.nextInt();

        try {
            rs = stmt.executeQuery("SELECT * FROM Seller WHERE seller_id = " + seller_id);
            if (rs.next()) {
                System.out.println("Seller ID: " + rs.getInt("seller_id"));
                System.out.println("Seller Name: " + rs.getString("name"));
                System.out.println("Seller Email: " + rs.getString("email"));
                System.out.println("Seller Address: " + rs.getString("address"));
                System.out.println("Seller Phone Number: " + rs.getString("phone_number"));
            } else {
                System.out.println("Seller not found!");
            }
        } catch (SQLException e) {
            System.out.println("Error viewing seller details: " + e.getMessage());
        }
    }

    private static void updateSellerInformation(Scanner scanner) {
        System.out.print("Enter seller ID: ");
        int seller_id = scanner.nextInt();
        System.out.print("Enter new seller name: ");
        String name = scanner.next();
        System.out.print("Enter new seller email: ");
        String email = scanner.next();
        System.out.print("Enter new seller address: ");
        String address = scanner.next();
        System.out.print("Enter new seller phone number: ");
        String phone_number = scanner.next();

        try {
            stmt.executeUpdate("UPDATE Seller SET name= '" + name + "', email = '" + email + "', address = '" + address + "', phone_number = '" + phone_number + "' WHERE seller_id = " + seller_id);
            System.out.println("Seller information updated successfully!");
        } catch (SQLException e) {
            System.out.println("Error updating seller information: " + e.getMessage());
        }
    }

    private static void deleteSeller(Scanner scanner) {
        System.out.print("Enter seller ID: ");
        int seller_id = scanner.nextInt();

        try {
            stmt.executeUpdate("DELETE FROM Seller WHERE seller_id = " + seller_id);
            System.out.println("Seller deleted successfully!");
        } catch (SQLException e) {
            System.out.println("Error deleting seller: " + e.getMessage());
        }
    }
    
    private static void registerNewBuyer(Scanner scanner) {
        System.out.print("Enter buyer name: ");
        String name = scanner.next();
        System.out.print("Enter buyer email: ");
        String email = scanner.next();
        System.out.print("Enter buyer address: ");
        String address = scanner.next();
        System.out.print("Enter buyer phone number: ");
        String phone_number = scanner.next();

        try {
            stmt.executeUpdate("INSERT INTO Buyer (name, email, address, phone_number) VALUES ('" + name + "', '" + email + "', '" + address + "', '" + phone_number + "')");
            System.out.println("Buyer registered successfully!");
        } catch (SQLException e) {
            System.out.println("Error registering buyer: " + e.getMessage());
        }
    }

    private static void viewBuyerDetails(Scanner scanner) {
        System.out.print("Enter buyer ID: ");
        int buyer_id = scanner.nextInt();

        try {
            rs = stmt.executeQuery("SELECT * FROM Buyer WHERE buyer_id = " + buyer_id);
            if (rs.next()) {
                System.out.println("Buyer ID: " + rs.getInt("buyer_id"));
                System.out.println("Buyer Name: " + rs.getString("name"));
                System.out.println("Buyer Email: " + rs.getString("email"));
                System.out.println("Buyer Address: " + rs.getString("address"));
                System.out.println("Buyer Phone Number: " + rs.getString("phone_number"));
            } else {
                System.out.println("Buyer not found!");
            }
        } catch (SQLException e) {
            System.out.println("Error viewing buyer details: " + e.getMessage());
        }
    }

    private static void updateBuyerInformation(Scanner scanner) {
        System.out.print("Enter buyer ID: ");
        int buyer_id = scanner.nextInt();
        System.out.print("Enter new buyer name: ");
        String name = scanner.next();
        System.out.print("Enter new buyer email: ");
        String email = scanner.next();
        System.out.print("Enter new buyer address: ");
        String address = scanner.next();
        System.out.print("Enter new buyer phone number: ");
        String phone_number = scanner.next();

        try {
            stmt.executeUpdate("UPDATE Buyer SET name= '" + name + "', email = '" + email + "', address = '" + address + "', phone_number = '" + phone_number + "' WHERE buyer_id = " + buyer_id);
            System.out.println("Buyer information updated successfully!");
        } catch (SQLException e) {
            System.out.println("Error updating buyer information: " + e.getMessage());
        }
    }

    private static void deleteBuyer(Scanner scanner) {
        System.out.print("Enter buyer ID: ");
        int buyer_id = scanner.nextInt();

        try {
            stmt.executeUpdate("DELETE FROM Buyer WHERE buyer_id = " + buyer_id);
            System.out.println("Buyer deleted successfully!");
        } catch (SQLException e) {
            System.out.println("Error deleting buyer: " + e.getMessage());
        }
    }

    

    private static void processNewTransaction(Scanner scanner) {
        System.out.print("Enter product ID: ");
        int product_id = scanner.nextInt();
        System.out.print("Enter seller ID: ");
        int seller_id = scanner.nextInt();
        System.out.print("Enter buyer ID: ");
        int buyer_id = scanner.nextInt();
        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();

        try {
            stmt.executeUpdate("INSERT INTO Transaction (product_id, seller_id, buyer_id, quantity, transaction_date, status) VALUES (" + product_id + ", " + seller_id + ", " + buyer_id + ", " + quantity + ", NOW(), 'pending')");
            System.out.println("Transaction processed successfully!");
        } catch (SQLException e) {
            System.out.println("Error processing transaction: " + e.getMessage());
        }
    }

    private static void viewTransactionDetails(Scanner scanner) {
        System.out.print("Enter transaction ID: ");
        int transaction_id = scanner.nextInt();

        try {
            rs = stmt.executeQuery("SELECT * FROM Transaction WHERE transaction_id = " + transaction_id);
            if (rs.next()) {
                System.out.println("Transaction ID: " + rs.getInt("transaction_id"));
                System.out.println("Product ID: " + rs.getInt("product_id"));
                System.out.println("Seller ID: " + rs.getInt("seller_id"));
                System.out.println("Buyer ID: " + rs.getInt("buyer_id"));
                System.out.println("Quantity: " + rs.getInt("quantity"));
                System.out.println("Transaction Date: " + rs.getDate("transaction_date"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("Transaction not found!");
            }
        } catch (SQLException e) {
            System.out.println("Error viewing transaction details: " + e.getMessage());
        }
    }

    private static void updateTransactionStatus(Scanner scanner) {
        System.out.print("Enter transaction ID: ");
        int transaction_id = scanner.nextInt();
        System.out.print("Enter new status (pending, shipped, delivered, cancelled): ");
        String status = scanner.next();

        try {
            stmt.executeUpdate("UPDATE Transaction SET status = '" + status + "' WHERE transaction_id = " + transaction_id);
            System.out.println("Transaction status updated successfully!");
        } catch (SQLException e) {
            System.out.println("Error updating transaction status: " + e.getMessage());
        }
    }

    private static void refundTransaction(Scanner scanner) {
        System.out.print("Enter transaction ID: ");
        int transaction_id = scanner.nextInt();

        try {
            stmt.executeUpdate("UPDATE Transaction SET status = 'efunded' WHERE transaction_id = " + transaction_id);
            System.out.println("Transaction refunded successfully!");
        } catch (SQLException e) {
            System.out.println("Error refunding transaction: " + e.getMessage());
        }
    }
}
    

    